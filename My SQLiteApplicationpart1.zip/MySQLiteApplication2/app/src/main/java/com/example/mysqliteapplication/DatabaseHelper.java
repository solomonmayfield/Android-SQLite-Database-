package com.example.mysqliteapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 *
 *

 2:35 / 10:53
 #SQLite #Android #ProgrammingKnowledge
 Android SQLite Database Tutorial 1 # Introduction + Creating Database and Tables (Part 1)
 *In this Android SQLite Database Tutorial  video I will give you the Introduction to using SqLite with android on Android Studio. In addition we will be Creating Database and Tables in our sqlite database for use in our android sqlite database tutorial.
 * This Android sqlite database tutorial for beginners
 * Developing Android Apps - Optional SQLite Tutorial I will show step by step How to insert, create,  update, delete, select data from SQLite using android app with android sqlite create database example. SQLite is an open-source social database i.e. used to perform database operations on android gadgets, for example, putting away, controlling or recovering relentless information from the database.
 * It is implanted in android by default. In this way, there is no compelling reason to play out any database setup or organization assignment.
 * Here, we are going to see the case of sqlite to store and get the information. Information is shown in the logcat. For showing information on the spinner or listview, move to the following page. SQLiteOpenHelper class gives the usefulness to utilize the SQLite database.
 *
 *
 */



public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Student.db";
    public static final String TABLE_NAME = "student_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "SURNAME";
    public static final String COL_4 = "MARKS";



    public DatabaseHelper(@Nullable Context context) {


        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
